load('transport.js');
var BASE_URL='https://truyenhub.net';
function thAbs(h){h=String(h||'');if(!h)return '';if(h.indexOf('http://')===0||h.indexOf('https://')===0)return h;if(h.charAt(0)!='/')h='/'+h;return BASE_URL+h;}
function thEnt(s){s=String(s||'');s=s.replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/&lt;/gi,'<').replace(/&gt;/gi,'>');return s.replace(/&#(x?[0-9a-f]+);/gi,function(a,n){var v=n.charAt(0).toLowerCase()==='x'?parseInt(n.substring(1),16):parseInt(n,10);return isNaN(v)?a:String.fromCharCode(v);});}
function thAttr(tag,name){var r=new RegExp('\\b'+name+'\\s*=\\s*(["\\\'])'+'([^"\\\']*)'+'\\1','i'),m=r.exec(String(tag||''));return m?thEnt(m[2]):'';}
function thText(s){s=String(s||'').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<br\s*\/?\s*>/gi,' ').replace(/<[^>]+>/g,' ');return thEnt(s).replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'');}

function execute(url){var h=thBrowserGet(url);if(!h)return Response.error('browser transport'),re=/<article\b[^>]*class\s*=\s*(["'])[^"']*chapter-content[^"']*\1[^>]*>([\s\S]*?)<\/article>/gi,m,content='';while((m=re.exec(h))!==null)content=m[2];if(!content){var p=h.search(/<div\b[^>]*id\s*=\s*(["'])chapter-content\1[^>]*>/i);if(p>=0){var sub=h.substring(p),am=/<article\b[^>]*>([\s\S]*?)<\/article>/i.exec(sub);if(am)content=am[1];}}return content?Response.success(content):Response.error('NO_CONTENT');}
